import tkinter as tk
from tkinter import PhotoImage
from io import BytesIO
import os
 

# Constants for the game thumbnail size and directory path
THUMBNAIL_SIZE = (150, 150)
GAME_DIRECTORY = "snes_roms/"

# Create the main window
root = tk.Tk()
root.title("SNES Games")

# Create a canvas for the game thumbnails
canvas = tk.Canvas(root, width=800, height=600)
canvas.pack()

# Create a frame for the game thumbnails
frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=frame, anchor="nw")

# Retrieve a list of SNES game files from the directory
game_files = os.listdir(GAME_DIRECTORY)

# Create a list to store game thumbnail images and labels
game_thumbnails = []

# Create a thumbnail image and label for each game file
for i, game_file in enumerate(game_files):
    # Load the game thumbnail image and resize it to the desired size
    with open(GAME_DIRECTORY + game_file, 'rb') as f:
        game_data = f.read()
    # write the game data to a BytesIO object
    game_image = BytesIO(game_data)
    
    # Convert the image to a Tkinter PhotoImage object
    game_photo = PhotoImage(master=root, data=game_image.tobytes())
    
    # Create a label to display the game thumbnail
    game_label = tk.Label(frame, image=game_photo)
    game_label.image = game_photo
    game_label.grid(row=i // 4, column=i % 4, padx=10, pady=10)
    
    # Add the game thumbnail and label to the list
    game_thumbnails.append((game_photo, game_label))

# Start the main loop
root.mainloop()
